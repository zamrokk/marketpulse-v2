export * from "./block.model"
export * from "./transaction.model"
export * from "./contractEventNewBet.model"
export * from "./_bet"
